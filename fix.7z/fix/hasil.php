<?php 
	include('koneksi.php');

	$nama = $_POST["nama"];
	$nim = $_POST["nim"];
	$ruangan = $_POST["ruangan"];
	$booking_date = $_POST["booking_date"];
	$booking_time = $_POST["booking_time"];
	$durasi = $_POST["durasi"];
	$purpose = $_POST["purpose"];
	$a = 100000;
	

	mysqli_query($connect, "INSERT INTO room SET nama='$nama', nim='$nim', ruangan='$ruangan',booking_date='$booking_date',booking_time ='$booking_time',durasi = '$durasi' , purpose='$purpose'");
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Hasil</title>
</head>
<body>

	<h2>Selamat anda berhasil dengan booking: </h2><br>
	<h2><?php 
	echo "Nama                        : ";
	echo $nama ?> <br></h2>

	<h2><?php
	echo "NIM                         : ";
	echo $nim ?> <br></h2>

	<h2><?php
	echo "Ruangan - Karyawan pengurus : ";
	echo $ruangan ?> <br></h2>

	<h2><?php 
	echo "Tanggal Penyewaan           : ";
	echo $booking_date ?> <br></h2>

	<h2><?php 
	echo "Jam Penyewaan               : ";
	echo $booking_time ?> <br></h2>

	<h2><?php 
	echo "Alasan Penyewaan            : ";
	echo $purpose ?> <br></h2>
	<h2><?php 
	echo "Total harga                 : Rp.  ";
	echo $a * $durasi;
	 ?></h2>
 	 <button href="http://localhost/coba/asset/index.php">Back</button>
	 
</body>
</html>