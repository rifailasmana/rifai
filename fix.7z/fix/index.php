<!DOCTYPE html>
<html>
<head>
    <!-- Load file CSS Bootstrap offline -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>
<body>
<div class="container">
<h2>ISI FORM DATA PEMINJAMAN</h2>
<br>
    <form action="hasil.php" method="post">
        <div class="form-group">
            <label>Nama:</label>
            <input type="text" name="nama" class="form-control" placeholder="Masukan nama" />
        </div>
        <div class="form-group">
            <label>Nim:</label>
            <input type="number" name="nim" class="form-control" placeholder="Masukan nim" />
        </div>
        <div class="form-group">
        <label>Ruangan - Karyawan</label>    
        <select name="ruangan" id="ruangan"class="form-control" placeholder="Pilih Ruangan">
          <option value="D1 - BENTO">D1 - ANTO</option>
          <option value="D2 - BENTO">D2 - BENTO</option>
          <option value="D3 - CRIPTO">D3 - CRIPTO</option>
          <option value="D4 - DITO">D4 - DITO</option>
        </select>
          
        </div>
        <div class="form-group">
            <label for="booking_date"> Booking Date: </label>
            <input type="Date" name="booking_date" class="form-control" id="booking_date" />
        </div>
        <div class="form-group">
            <label for="booking_date"> Booking Time: </label>
            <input type="Time" name="booking_time" class="form-control" id="booking_time" />
        </div>

        <div class="form-group">
            <label>Durasi Pemakaian (/Jam)</label>
            <input type="text" name="durasi" class="form-control" placeholder="Durasi Pemakaian" />
        </div>

        <div class="form-group">
            <label>Purpose</label>
            <input type="text" name="purpose" class="form-control" placeholder="Masukan Alasan" />
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
        
    </form>
</div>
</body>
</html>