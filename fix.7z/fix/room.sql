-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 28 Jun 2020 pada 20.04
-- Versi server: 10.4.13-MariaDB
-- Versi PHP: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coba`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `room`
--

CREATE TABLE `room` (
  `nama` varchar(30) CHARACTER SET armscii8 DEFAULT '' COMMENT 'nama',
  `nim` int(10) NOT NULL COMMENT 'nim',
  `ruangan` varchar(255) NOT NULL COMMENT 'ruangan',
  `booking_date` date NOT NULL COMMENT 'booking date',
  `booking_time` time NOT NULL COMMENT 'booking time',
  `durasi` int(2) NOT NULL,
  `purpose` varchar(250) CHARACTER SET armscii8 DEFAULT NULL COMMENT 'purpose'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `room`
--

INSERT INTO `room` (`nama`, `nim`, `ruangan`, `booking_date`, `booking_time`, `durasi`, `purpose`) VALUES
('BAMBANG', 2147483647, 'empat', '2020-07-01', '00:00:00', 0, 'MMMMMM'),
('asd', 2147483647, 'empat', '2020-07-01', '00:00:00', 0, 'MMMMMM'),
('asd', 2147483647, 'empat', '2020-07-01', '08:15:00', 0, 'MMMMMM'),
('asd', 2147483647, 'empat', '2020-07-01', '08:15:00', 0, 'MMMMMM'),
('asd', 2147483647, 'empat', '2020-07-01', '08:15:00', 0, 'MMMMMM'),
('asd', 2147483647, 'empat', '2020-07-01', '08:15:00', 0, 'MMMMMM'),
('Muhammad Rifai Lasmana', 2147483647, 'tiga', '2020-07-01', '07:00:00', 2, 'MAKAN'),
('Muhammad Rifai Lasmana', 2147483647, 'tiga', '2020-07-01', '07:00:00', 2, 'MAKAN'),
('ANTO', 123, 'D4 - DITO', '2020-06-30', '01:45:00', 2, 'BERR'),
('gila', 123, 'D4 - DITO', '2020-06-30', '01:45:00', 2, 'BERR'),
('gila', 123, 'D4 - DITO', '2020-06-30', '01:45:00', 5, 'BERR'),
('gila', 123, 'D4 - DITO', '2020-06-30', '01:45:00', 5, 'BERR'),
('gila', 123, 'D4 - DITO', '2020-06-30', '01:45:00', 5, 'BERR'),
('gila', 123, 'D4 - DITO', '2020-06-30', '01:45:00', 5, 'BERR'),
('gila', 123, 'D4 - DITO', '2020-06-30', '01:45:00', 5, 'BERR'),
('gila', 123, 'D4 - DITO', '2020-06-30', '01:45:00', 5, 'BERR'),
('gila', 123, 'D4 - DITO', '2020-06-30', '01:45:00', 5, 'BERR'),
('gila', 123, 'D4 - DITO', '2020-06-30', '01:45:00', 5, 'BERR'),
('gila', 123, 'D4 - DITO', '2020-06-30', '01:45:00', 5, 'BERR'),
('', 0, 'D1 - BENTO', '0000-00-00', '00:00:00', 0, '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
